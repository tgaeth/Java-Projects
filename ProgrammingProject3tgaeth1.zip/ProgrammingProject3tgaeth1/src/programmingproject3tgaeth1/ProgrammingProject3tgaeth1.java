/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject3tgaeth1;

/**
 *
 * @author tomga_000
 */
public class ProgrammingProject3tgaeth1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name;
        String address;
        String callTime;
        String phoneNum;
        String emergency;
        String response;
        String display;
        Emergency dispatch = new Emergency();
        
        name = dispatch.getName();
        address = dispatch.getCallLocation();
        phoneNum = dispatch.getNum();
        emergency = dispatch.getType();
        callTime = dispatch.getTime();
        response = dispatch.dispatchResponse(emergency);
        display = dispatch.displayInformation(name, address, phoneNum, emergency, callTime, response);
        System.out.printf("%s%n", display);
        
    }
    
}
