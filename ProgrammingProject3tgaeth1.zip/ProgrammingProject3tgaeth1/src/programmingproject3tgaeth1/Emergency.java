/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject3tgaeth1;
import java.security.SecureRandom;
/**
 *
 * @author tomga_000
 */
public class Emergency {
    private String callerLocation;//necessary to find dispatch location, contains city/state/postal code info.
    private String callerName;//name of citizen making complaint.
    private String emergType;// type of emergency. Police, Fire, EMS.
    private String callerNumber;//callers phone number as a string.
    private String dispatchResponse;//records the dispatch response.
    
    
    public String getCallLocation(){//retirves caller location
        SecureRandom rand = new SecureRandom();
        int location = 1 + rand.nextInt(5);//gets address for testing
        switch(location){
            case 1: 
                callerLocation = "3652 Chruchville Road, Aberdeen, Maryland 21017";
                break;
            case 2:
                callerLocation = "43 S. Hampton Street, Biloxi, Mississippi 36531";
                break;
            case 3:
                callerLocation = "281 Workman's Road, Abingdon, Maryland 21009";
                break;
            case 4:
                callerLocation = "45 Exton Road, Bowie, Maryland 20717";
                break;
            case 5:
                callerLocation = "69 Left Turn Road, Albuquerque, New Mexico 87101";
                break;
        }
        return callerLocation;
    }
    public String getName(){//gets caller name
        SecureRandom rand = new SecureRandom();
        int name = 1 + rand.nextInt(5);//gets name for testing
        switch(name){
            case 1: 
                callerName = "Tom Gaeth";
                break;
            case 2: 
                callerName = "Jon Rice";
                break;
            case 3: 
                callerName = "Amy Hanzelik";
                break;
            case 4: 
                callerName = "James Bond";
                break;
            case 5: 
                callerName = "Guy Weird";
                break;
        }
        return callerName;
    }
    public String getNum(){//gets caller phone number
        SecureRandom rand = new SecureRandom();
        int caller = 1 + rand.nextInt(5);//produces random number for testing
        switch(caller){
            case 1: 
                callerNumber = "443-945-4639";
                break;
            case 2: 
                callerNumber = "410-569-3600";
                break;
            case 3: 
                callerNumber = "420-371-5698";
                break;
            case 4: 
                callerNumber = "410-468-9821";
                break;
            case 5: 
                callerNumber = "443-697-8828";
                break;
        }
        return callerNumber;
    }
    public String getType(){//retrives emergency type
        SecureRandom rand = new SecureRandom();
        int type = 1 + rand.nextInt(3);//randomly selects emergency type for testing purposes
        switch(type){
            case 1: 
                emergType = "Police";
                break;
            case 2: 
                emergType = "Fire";
                break;
            case 3: 
                emergType = "EMS";
                break;
        }
        return emergType;
    }
    public String getTime(){//selects random time for purpose of testing
        SecureRandom rand = new SecureRandom();
        int hour = rand.nextInt(23);
        int minute = rand.nextInt(59);
        return String.format("%02d:%02d", hour, minute);
    }
    public String dispatchResponse(String type){
        if("Police".equals(type))
            dispatchResponse = "Police dispatched.";
        if("Fire".equals(type))
            dispatchResponse = "Fire Departement dispatched.";
        if("EMS".equals(type))
            dispatchResponse = "EMS dispatched.";
        return dispatchResponse;
    }
    public String displayInformation(String name, String location, String number, String type, String time, String response){
        return String.format("%s%n%s%n%s%nEmergency Type: %s%nTime Called: %s%n%s%n", name, location, number, type, time, response);
    }
}
