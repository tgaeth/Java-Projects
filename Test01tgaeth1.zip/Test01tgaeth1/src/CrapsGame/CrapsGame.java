/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CrapsGame;
import java.util.Scanner;
import java.security.SecureRandom;
/**
 *
 * @author tomga_000
 */
public class CrapsGame {
    private static final SecureRandom randomNumbers = new SecureRandom();
    private static final Scanner input = new Scanner(System.in);
    
    public enum Status{CONTINUE, WON, LOST};
    
    private static final int SNAKE_EYES = 2;
    private static final int TREY = 3;
    private static final int SEVEN = 7;
    private static final int YO_LEVEN = 11;
    private static final int BOX_CARS = 12;
    
    public static void main(String[] args){
        int myPoint = 0;
        Status gameStatus;
        int bankBalance = 1000;
        int wager;
        MethodsCraps craps = new MethodsCraps();
        
        while(bankBalance > 0){
            wager = craps.Wager(bankBalance);
            
            int sumOfDice = craps.rollDice();
            
            switch(sumOfDice){
                case SEVEN:
                case YO_LEVEN:
                    gameStatus = Status.WON;
                    break;
                case SNAKE_EYES:
                case TREY:
                case BOX_CARS:
                    gameStatus = Status.LOST;
                    break;
                default:
                    gameStatus = Status.CONTINUE;
                    myPoint = sumOfDice;
                    System.out.printf("Point is %d%n" , myPoint);
                    break;
            }
            while(gameStatus == Status.CONTINUE){
                sumOfDice = craps.rollDice();
                
                if(sumOfDice == myPoint)
                    gameStatus = Status.WON;
                else if(sumOfDice == SEVEN)
                    gameStatus = Status.LOST;
            }
            if(gameStatus == Status.WON){
                System.out.println("Player wins");
                bankBalance += wager;
            }
            else{
                System.out.println("Player loses");
                bankBalance -= wager;
            }
            System.out.printf("Bank Balance: %d%n", bankBalance);
            if(bankBalance == 0)
                System.out.printf("Sorry you Busted!%n");
            String rand = craps.chatter();
            System.out.print(rand);
        }
    }
}
