/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CrapsGame;
import java.security.SecureRandom;
import java.util.Scanner;
/**
 *
 * @author tomga_000
 */
public class MethodsCraps {
    private static SecureRandom randomNumbers = new SecureRandom();
    private static Scanner input = new Scanner(System.in);
    public int rollDice(){
        int die1 = 1 + randomNumbers.nextInt(6);
        int die2 = 1 + randomNumbers.nextInt(6);
        
        int sum = die1 + die2;
        
        System.out.printf("Player rolled: %d + %d = %d%n", die1, die2, sum);
        
        return sum;
    }
    public int Wager(int bankBalance){
        System.out.print("Enter a wager: ");
        int wager = input.nextInt();
        int x = 0;
        while(x == 0){
            if(wager <= bankBalance)
                x = 1;
            else{
                System.out.print("Invalid wager. Enter another.");
                wager = input.nextInt();
            }
        }
        return wager;
    }
    public String chatter(){
        int x = 1 + randomNumbers.nextInt(4);
        String randomChatter = null;
        switch(x){
            case 1:
                randomChatter = "Oh, you're going for broke, huh? ";
                break;
            case 2:
                randomChatter = "Aw c'mon, take a chance! ";
                break;
            case 3:
                randomChatter = "You're up big, now's the time to cash in your chips! ";
                break;
            case 4: 
                randomChatter = "Go ahead break the bank! ";
                break;
        }
        return randomChatter;
    }
}
