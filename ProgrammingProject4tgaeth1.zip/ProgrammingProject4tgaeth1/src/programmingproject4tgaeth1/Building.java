/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject4tgaeth1;

/**
 *
 * @author tomga_000
 */
public class Building implements CarbonFootprint{
    private double electricUsed;
    private double naturalGasUsed;
    private double heatingOilUsed;
    private double propaneUsed;
    
    public Building(double electricUsed, double naturalGasUsed, double heatingOilUsed,
            double propaneUsed){
        
        if(electricUsed < 0)
            throw new IllegalArgumentException("Electric Used must be >= 0");
        
        if(naturalGasUsed < 0)
            throw new IllegalArgumentException("Natrual Gas Used must be >= 0");
        
        if(heatingOilUsed < 0)
            throw new IllegalArgumentException("Heating Oil Used must be >= 0");
        
        if(propaneUsed < 0)
            throw new IllegalArgumentException("Propane Used must be >= 0");
        
        this.electricUsed = electricUsed;
        this.naturalGasUsed = naturalGasUsed;
        this.heatingOilUsed = heatingOilUsed;
        this.propaneUsed = propaneUsed;
    }
    
    public void setElectricUsed(double electricUsed){
        if(electricUsed < 0)
            throw new IllegalArgumentException("Electric Used must be >= 0");
        this.electricUsed = electricUsed;
    }
    
    public double getElectricUsed(){
        return electricUsed;
    }
    
    public void setNaturalGasUsed(double naturalGasUsed){
        if(naturalGasUsed < 0)
            throw new IllegalArgumentException("Natrual Gas Used must be >= 0");
        this.naturalGasUsed = naturalGasUsed;
    }
    
    public double getNaturalGasUsed(){
        return naturalGasUsed;
    }
    
    public void setHeatingOilUsed(double heatingOilUsed){
        if(heatingOilUsed < 0)
            throw new IllegalArgumentException("Heating Oil Used must be >= 0");
        this.heatingOilUsed = heatingOilUsed;
    }
    
    public double getHeatingOilUsed(){
        return heatingOilUsed;
    }
    
    public void setPropaneUsed(double propaneUsed){
        if(propaneUsed < 0)
            throw new IllegalArgumentException("Propane Used must be >= 0");
        this.propaneUsed = propaneUsed;
    }
    
    public double getPropaneUsed(){
        return propaneUsed;
    }
    
    @Override
    public double getCarbonFootprint(){
        return (0.00005925 * getElectricUsed()) + (0.005 * getNaturalGasUsed()) 
                + (22.37692 * getHeatingOilUsed()) + (12.65453 * getPropaneUsed());
    }
    
    @Override
    public String toString(){
        return String.format("%nBuilding Footprint:%n%s%s%n%s%s%n%s%s%n%s%s%n%s%s%n", 
                "Electricity Used(kWh): ", getElectricUsed(), "Natural Gas Used(therms): ", 
                getNaturalGasUsed(), "Heating Oil Used(gallons): ",getHeatingOilUsed(), 
                "Propane Used(gallons): ", getPropaneUsed(), "Carbon Footprint(lbs): ", getCarbonFootprint());
    }
}
