/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject4tgaeth1;

/**
 *
 * @author tomga_000
 */
public class Car implements CarbonFootprint{
    private double gasolineUsage;
    
    public Car(double gasolineUsage){
        if(gasolineUsage < 0)
            throw new IllegalArgumentException("Gasoline Usage must be >= 0");
        this.gasolineUsage = gasolineUsage;
    }
    
    public void setGasolineUsage(double gasolineUsage){
        if(gasolineUsage < 0)
            throw new IllegalArgumentException("Gasoline Usage must be >= 0");
        this.gasolineUsage = gasolineUsage;
    }
    
    public double getGasolineUsage(){
        return gasolineUsage;
    }
    
    @Override
    public double getCarbonFootprint(){
        return 19.64319 * getGasolineUsage();
    }
    
    @Override
    public String toString(){
        return String.format("%nCar Footprint:%n%s%s%n%s%s%n", "Gasoline Usage(gallons): ",
                getGasolineUsage(), "Carbon Footprint(lbs): ", getCarbonFootprint());
    }
}
