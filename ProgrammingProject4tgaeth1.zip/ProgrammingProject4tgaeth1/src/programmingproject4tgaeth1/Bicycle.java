/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject4tgaeth1;

/**
 *
 * @author tomga_000
 */
public class Bicycle implements CarbonFootprint{
    private double foodConsumed;
    
    public Bicycle(double foodConsumed){
        if(foodConsumed < 0)
            throw new IllegalArgumentException("Food Consumed must be >= 0");
        this.foodConsumed = foodConsumed;
    }
    
    public void setFoodConsumed(double foodConsumed){
        if(foodConsumed < 0)
            throw new IllegalArgumentException("Food Consumed must be >= 0");
        this.foodConsumed = foodConsumed;
    }
    
    public double getFoodConsumed(){
        return foodConsumed;
    }
    
    @Override
    public double getCarbonFootprint(){
        return getFoodConsumed() * (1.7 / 500);
    }
    
    @Override
    public String toString(){
        return String.format("%nBicycle Footprint:%n%s%s%n%s%s%n", "Food Consumed(calories): ",
                getFoodConsumed(), "Carbon Footprint(lbs): ", getCarbonFootprint());
    }
}
