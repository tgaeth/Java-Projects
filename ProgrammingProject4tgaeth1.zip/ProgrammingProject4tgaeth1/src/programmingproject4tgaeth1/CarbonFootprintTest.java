/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject4tgaeth1;

/**
 *
 * @author tomga_000
 */
public class CarbonFootprintTest {
    public static void main(String[] args){
        Building building = new Building(10, 2, 60, 20);
        Car car = new Car(24);
        Bicycle bicycle = new Bicycle(500);
        
        CarbonFootprint[] ArrayList = new CarbonFootprint[3];
        
        ArrayList[0] = building;
        ArrayList[1] = car;
        ArrayList[2] = bicycle;
        
        for(CarbonFootprint currentFootprint : ArrayList)
            System.out.print(currentFootprint.toString());
    }
}
