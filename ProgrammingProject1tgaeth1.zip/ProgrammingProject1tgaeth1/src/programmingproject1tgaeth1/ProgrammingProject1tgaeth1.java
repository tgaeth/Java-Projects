
package programmingproject1tgaeth1;
import java.util.Scanner;

public class ProgrammingProject1tgaeth1 {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int y = 1 ;
        int x = 0;
        double wcom;
        double tcom = 0;
        double bpay;
        double gsal = 0;
        String name;
        
        TotalSales find = new TotalSales();
        name = find.getName();
        
        while (y == 1)
        {
            wcom = find.getSales();
            gsal += wcom + 200;
            tcom += wcom;
            x++;
            System.out.print("Enter 1 to continue or 0 to exit. ");
            y = input.nextInt();
        }
        bpay = 200 * x;
        System.out.printf("%nSalesperson: %s%nCommission: $%.2f%nBase Pay:  $%.2f%nGross Pay: $%.2f%n", name, tcom, bpay, gsal);
        
    }
    
}
