/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject1tgaeth1;
import java.util.Scanner;
/**
 *
 * @author tomga_000
 */
public class TotalSales {
    Scanner input = new Scanner(System.in);
    
    private double item;
    private int x=1;
    private String name;
    private double tot1;
    private double tot2;
    private double tot3;
    private double tot4;
    private double ototal;
    private double commission;
    
    public double getSales()
    {
        while(x <= 4)
        {
         System.out.printf("Please enter the total number of item %d that was sold: ", x);
         item = input.nextDouble();
         if(x==1)
             tot1 = item * 239.99;
         if(x==2)
             tot2 = item * 129.75;
         if(x==3)
             tot3 = item * 99.95;
         if(x==4)
             tot4 = item * 350.89;
         x++;
        }
        x = 1;
        ototal = tot1 + tot2 + tot3 + tot4;
        commission = ototal * .09;
         return commission;
    } 
    public String getName()
    {
        System.out.print("Enter Salespersons name: ");
        name = input.next();
        
        return name;
    }
}       
        
       
        
       
        
    


