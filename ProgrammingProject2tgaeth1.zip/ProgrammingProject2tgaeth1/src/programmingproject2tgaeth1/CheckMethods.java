/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject2tgaeth1;
import java.security.SecureRandom;
import java.util.Scanner;
/**
 *
 * @author tomga_000
 */
public class CheckMethods {
    public static int questGenerator(){
        SecureRandom digit = new SecureRandom();
        Scanner input = new Scanner(System.in);
        
        int IntOne;
        int IntTwo;
        int crtAnswer;
        IntOne = 1 + digit.nextInt(9);
        IntTwo = 1 + digit.nextInt(9);
        crtAnswer = IntOne * IntTwo;
        System.out.printf("What is %d times %d?", IntOne, IntTwo);
        return crtAnswer;
    }
    public static boolean answerCheck(int x){
        Scanner input = new Scanner(System.in);
        int newAnswer = input.nextInt();
        boolean check;
        check = x == newAnswer;//says check = true if x is equal to newAnswer
        return check;
    }
    public static void randResponse(boolean x, int answer){
        SecureRandom response = new SecureRandom();
        int y; 
        if(x == true){
            y = 1 + response.nextInt(4);
            switch(y){
                case 1:
                    System.out.print("Great Job! Do you want to exit? Enter 1 to exit, 0 to continue. ");
                    break;
                case 2:
                    System.out.print("Nice Work! Do you want to exit? Enter 1 to exit, 0 to continue. ");
                    break;
                case 3:
                    System.out.print("Well Done! Do you want to exit? Enter 1 to exit, 0 to continue. ");
                    break;
                case 4:
                    System.out.print("Excellent Answer! Do you want to exit? Enter 1 to exit, 0 to continue. ");
                    break;
            }
        }
        else{
            while(x == false){
                y = 1 + response.nextInt(4);
                switch(y){
                    case 1:
                        System.out.printf("Sorry that is incorrect, try again. Answer: ");
                        break;
                    case 2:
                        System.out.print("Oh no, that's incorrect, try again. Answer: ");
                        break;
                    case 3:
                        System.out.print("Give it another try! Answer: ");
                        break;
                    case 4:
                        System.out.print("Keep trying you'll get it! Answer: ");
                        break;
                }
                x = CheckMethods.answerCheck(answer);         
            }
            System.out.print("Great Job! Do you want to exit? Enter 1 to exit, 0 to continue. ");
        }
    }
    
    
}
