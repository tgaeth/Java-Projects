/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject2tgaeth1;

import java.util.Scanner;

/**
 *
 * @author tomga_000
 */
public class problem636 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int answer;
        boolean check;
        int x = 0;
        while(x != 1){
            answer = CheckMethods.questGenerator();
            check = CheckMethods.answerCheck(answer);
            CheckMethods.randResponse(check, answer);
            x = input.nextInt();
        }
    }
}
