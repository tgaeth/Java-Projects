/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingproject2tgaeth1;
import java.util.Scanner;
/**
 *
 * @author tomga_000
 */
public class problem635 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int answer;
        boolean check;
        int x = 0;
        while(x != 1){
            answer = CheckMethods.questGenerator();
            check = CheckMethods.answerCheck(answer);
            if(check == true)
                System.out.print("Great Job! Do you want to exit? Enter 1 to exit, 0 to continue. ");
            else{
                while(check == false){
                    System.out.printf("Sorry that is incorrect, try again. Answer: ");
                    check = CheckMethods.answerCheck(answer);
                }
                System.out.print("Great Job! Do you want to exit? Enter 1 to exit, 0 to continue. ");
            }
            x = input.nextInt();
        }
    }
}
